package com.demo.loadbalancer.model;

import lombok.experimental.UtilityClass;

public class Constant {
    public static final String ROUND_ROBIN="ROUND_ROBIN";
    public static final String RANDOM="RANDOM";

}
