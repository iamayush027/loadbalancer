package com.demo.loadbalancer.config;


import com.demo.loadbalancer.model.BackendServer;
import com.demo.loadbalancer.service.LoadBalancerService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.Arrays;

@Configuration
public class LoadBalancerConfig {

//    @Bean
//    public LoadBalancerService loadBalancerService() {
//        LoadBalancerService service = new LoadBalancerService("round-robin");
//        service.addBackendServer(new BackendServer("localhost", 8081));
//        service.addBackendServer(new BackendServer("localhost", 8082));
//        return service;
//    }
}

